module Calc {
	requires junit;
}