package junitproject;

public class Calculator {
	public static int add(int number1, int munber2) {
		
		return number1 + number2;
	}
	public static int sub(int number1, int number2) {
		return number1 - number2;
		
	}
public static int mul (int number1, int numbe2) {
	
	return number1 * number2;
	
}
public static double div(double number1, double number2) {
	if(number2 ==0) {
		throw now IllegalArgumentException("Number can not be divided by 0!");
	}
	return number1 / number2;
}
}
