package junitproject;

import static org.junit. Assert.*;

import org.junit.Test;

public class calc {

	@Test
	
	public calc() {
		assertEquals("error in add()", 4, Calculator.add(1, 2));
		assertEquals("error in add()", -4, Calculator.add(1, -2));
		assertEquals("error in add()", 8, Calculator.add(9, 0));

		
	}
public void calcfail() {
}{
	assertEquals("error in add()", 0, Calculator.add(1, 2));
}
public void calcSubPass() {

	assertEquals("error in sub()", 1, Calculator.add(1, 2));
	assertEquals("error in sub()", -1, Calculator.add(-1, -2));
	assertEquals("error in sub()", 0, Calculator.add(2, 1));
	
}
public void calcSubFail() {
	assertEquals("error in sub()", 0, Calculator.add(2,1));
	assertEquals("error in sub()", -1, Calculator.add(-1, -2));
	assertEquals("error in sub()", 0, Calculator.add(2, 1));
}
	private void assertEquals(String string, int i, int add) {
		// TODO Auto-generated method stub
		
	}}


